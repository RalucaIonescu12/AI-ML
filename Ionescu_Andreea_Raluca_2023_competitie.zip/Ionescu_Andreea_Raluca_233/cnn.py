from keras.utils import np_utils
from sklearn.utils import shuffle
from tensorflow.keras import layers
from keras.utils.np_utils import to_categorical
import numpy as np
from PIL import Image
import pandas as pd
import csv
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.utils import to_categorical
from sklearn.metrics import confusion_matrix
import seaborn as sns
from matplotlib.colors import ListedColormap
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_recall_fscore_support

def citire_date():
    
    poze_antrenare = []
    etichete_antrenare = []
    poze_validare = []
    etichete_validare = []
    poze_test = []
    folder='train_images/'
    # citire date antrenare
    fisier = pd.read_csv('train.csv')
    for _, linie in fisier.iterrows():
        path =  folder + linie['Image']
        poza= Image.open(path)
        poza = poza.resize((32, 32))
        poza= np.array(poza)
        poze_antrenare.append(poza)
        etichete_antrenare.append(linie['Class'])

    fisier = pd.read_csv('val.csv')

    folder='val_images/'
    for _, linie in fisier.iterrows():
        path = folder + linie['Image']
        poza= Image.open(path)
        poza = poza.resize((32, 32))
        poza= np.array(poza)
        poze_validare.append(poza)
        etichete_validare.append(linie['Class'])

   
    fisier = pd.read_csv('test.csv')
    folder= 'test_images/'
    for _, linie in fisier.iterrows():
        path = folder + linie['Image']
        poza = Image.open(path)
        poza = poza.resize((32, 32))
        poza = np.array(poza)
        poze_test.append(poza)

    # print(poze_antrenare[0].shape)

    poze_validare = np.array(poze_validare)
    etichete_validare = np.array(etichete_validare)
    poze_antrenare = np.array(poze_antrenare)
    etichete_antrenare = np.array(etichete_antrenare)
    poze_test = np.array(poze_test)
    
    # se obțin valori între 0 și 1
    # normalizare date inainte de antrenare
    poze_antrenare=poze_antrenare/255.0
    poze_validare=poze_validare/255.0
    poze_test=poze_test/255.0
    
    # print(poze_antrenare.shape) 
     
    return etichete_antrenare, poze_antrenare,etichete_validare,poze_validare, poze_test  
     
# citire_date()                         

def antrenare():
    
    etichete_antrenare, poze_antrenare,etichete_validare,poze_validare, poze_test=citire_date()
    poze_antrenare, etichete_antrenare = shuffle(poze_antrenare, etichete_antrenare)
    poze_validare, etichete_validare = shuffle(poze_validare, etichete_validare)
    fisier_poze_test=pd.read_csv('test.csv')
    nume_poze_teste=fisier_poze_test['Image']
    # reprezentare one-hot encoding
    antrenare = np_utils.to_categorical(etichete_antrenare,96)
    val = np_utils.to_categorical(etichete_validare,96)
    
    model = keras.Sequential()
    #relu introduce non-linearitate=>orice valoare negativa din feature map este înlocuita 
    #cu zero,valorile pozitive nemodificate. 
    #primeste un input de forma (32, 32, 3) si aplica 32 de filtre de dimensiune (3, 3)
    #asupra imaginilor
    model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=(32, 32, 3)))
    #ia output-ul stratului anterior si aplica 64 de filtre de dimensiune (3, 3)
    model.add(layers.Conv2D(64, (3, 3), activation='relu'))
    # reduce dimensiunea output-ului =>selecteaza valoarea maxima din fiecare regiune
    # reducere numarul de parametri
    model.add(layers.MaxPooling2D((2, 2)))
    model.add(layers.MaxPooling2D((2, 2)))
    #transforma matricea tridimensională in vector liniar
    model.add(layers.Flatten())
    # stratul dens finalcu 96 neuroni cu functia de activare 'softmax'
    # =>și estimeaza probabilitatile
    model.add(layers.Dense(96, activation='softmax'))
    
    
    model.summary()

    # configurare model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    # antrenează modelul pe datele de antrenare si valideaza performanta pe datele de validare
    history = model.fit(poze_antrenare, antrenare, batch_size=32, epochs=100,  validation_data=(poze_validare, val))
   
   
    
    predictions = model.predict(poze_test)
   
    predicted_labels = np.argmax(predictions, axis=1)

    # fisier csv pentru submisie
    submisie = list(zip(nume_poze_teste, predictions))
    pd.DataFrame(submisie, columns=['Image', 'Class']).to_csv('submisieNB.csv', index=False)
    
    #####################################################################################################################  
    #  matricea de confuzie
    predictions = model.predict(poze_validare)
    confusion = confusion_matrix(etichete_validare, predictions)

    class_labels = [str(i) for i in range(1, 97)]

    fig, ax = plt.subplots(figsize=(48, 48))
    sns.heatmap(confusion, annot=True, fmt='d', cmap='Blues', ax=ax)
    ax.set_xlabel('Clasa prezisa')
    ax.set_ylabel('Clasa reala')
    ax.set_title('Matrice de confuzie')
    ax.xaxis.set_ticklabels(class_labels, rotation='vertical')
    ax.yaxis.set_ticklabels(class_labels, rotation='horizontal')
    plt.show()


    precision, recall, _, support = precision_recall_fscore_support(etichete_validare, model.predict(poze_validare) , zero_division=0)
    print("Raport validare:")
    plt.figure(figsize=(48, 48))
    plt.bar(range(len(precision)), precision)
    plt.xlabel('Clasa')
    plt.ylabel('Precizie')
    plt.title('Precizia claselor')
    plt.xticks(range(len(precision)), labels=range(len(precision)))
    plt.show()

    plt.figure(figsize=(48, 48))
    plt.bar(range(len(recall)), recall)
    plt.xlabel('Clasa')
    plt.ylabel('Recall')
    plt.title('Recall pentru fiecare clasa')
    plt.xticks(range(len(recall)), labels=range(len(recall)))
    plt.show()

    plt.figure(figsize=(48, 48))
    plt.bar(range(len(support)), support)
    plt.xlabel('Clasa')
    plt.ylabel('Numar')
    plt.title('Numarul de exemple din fiecare clasa')
    plt.xticks(range(len(recall)), labels=range(len(recall)))
    plt.show()   


    training_loss = history.history['loss']
    validation_loss = history.history['val_loss']

    epochs = range(1, 101)
    plt.plot(epochs, training_loss, 'b', label='Training Loss')
    plt.plot(epochs, validation_loss, 'r', label='Validation Loss')
    plt.title('Training and Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()
            
    training_loss = history.history['accuracy']
    validation_loss = history.history['val_accuracy']

    epochs = range(1, 101)
    plt.plot(epochs, training_loss, 'g', label='Training Accuracy')
    plt.plot(epochs, validation_loss, 'r', label='Validation Accuracy')
    plt.title('Training and Validation Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.show()
    
antrenare()   
