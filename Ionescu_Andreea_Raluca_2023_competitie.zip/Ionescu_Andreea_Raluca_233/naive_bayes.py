import numpy as np
from PIL import Image
import pandas as pd
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import GaussianNB
import matplotlib.pyplot as plt
import csv
from sklearn.metrics import confusion_matrix
import seaborn as sns
from matplotlib.colors import ListedColormap
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_recall_fscore_support

poze_antrenare = []
etichete_antrenare = []
poze_validare = []
etichete_validare = []
poze_test = []

# citire date antrenare
folder='train_images/'
fisier = pd.read_csv('train.csv')

for _, linie in fisier.iterrows():
    path =  folder + linie['Image']
    poza= Image.open(path)
    poza = poza.resize((32, 32))
    poza= np.array(poza)
    poze_antrenare.append(poza)
    etichete_antrenare.append(linie['Class'])


# citire date validare
fisier = pd.read_csv('val.csv')

folder='val_images/'
for _, linie in fisier.iterrows():
    path = folder + linie['Image']
    poza= Image.open(path)
    poza = poza.resize((32, 32))
    poza= np.array(poza)
    poze_validare.append(poza)
    etichete_validare.append(linie['Class'])


#citire date test
fisier = pd.read_csv('test.csv')
folder= 'test_images/'
for _, linie in fisier.iterrows():
    path = folder + linie['Image']
    poza = Image.open(path)
    poza = poza.resize((32, 32))
    poza = np.array(poza)
    poze_test.append(poza)
fisier_poze_test=pd.read_csv('test.csv')
nume_poze_teste=fisier_poze_test['Image']

    
# print(poze_antrenare[0].shape)

poze_validare = np.array(poze_validare)
etichete_validare = np.array(etichete_validare)
poze_antrenare = np.array(poze_antrenare)
etichete_antrenare = np.array(etichete_antrenare)
poze_test = np.array(poze_test)

# convertire la o sg dimensiune
poze_antrenare = poze_antrenare.reshape(poze_antrenare.shape[0], -1)
poze_validare = poze_validare.reshape(poze_validare.shape[0], -1)
poze_test = poze_test.reshape(poze_test.shape[0], -1)

# normalizare

# mean_image = np.mean(poze_test)
# std = np.std(poze_test)
# norm_images = (poze_test - mean_image) / std

# poze_antrenare=poze_antrenare/255.0
# poze_validare=poze_validare/255.0
# poze_test=poze_test/255.0

# print(poze_antrenare.shape) 


model = GaussianNB()
# antrenare
model.fit(poze_antrenare, etichete_antrenare)
scor_antrenare = model.score(poze_antrenare, etichete_antrenare)
scor_validare = model.score(poze_validare, etichete_validare)

print(f"Train Acc: {scor_antrenare}, Val Acc: {scor_validare}")


predictions = model.predict(poze_test)

# fisier csv pentru submisie
submisie = list(zip(nume_poze_teste, predictions))
pd.DataFrame(submisie, columns=['Image', 'Class']).to_csv('submisieNB.csv', index=False)



#####################################################################################################################
# matricea de confuzie
predictions = model.predict(poze_validare)
confusion = confusion_matrix(etichete_validare, predictions)

class_labels = [str(i) for i in range(1, 97)]

fig, ax = plt.subplots(figsize=(48, 48))
sns.heatmap(confusion, annot=True, fmt='d', cmap='Blues', ax=ax)
ax.set_xlabel('Clasa prezisa')
ax.set_ylabel('Clasa reala')
ax.set_title('Matrice de confuzie')
ax.xaxis.set_ticklabels(class_labels, rotation='vertical')
ax.yaxis.set_ticklabels(class_labels, rotation='horizontal')
plt.show()

# rapoarte
precision, recall, _, support = precision_recall_fscore_support(etichete_validare, model.predict(poze_validare) , zero_division=0)
print("Raport validare:")
plt.figure(figsize=(48, 48))
plt.bar(range(len(precision)), precision)
plt.xlabel('Clasa')
plt.ylabel('Precizie')
plt.title('Precizia claselor')
plt.xticks(range(len(precision)), labels=range(len(precision)))
plt.show()

plt.figure(figsize=(48, 48))
plt.bar(range(len(recall)), recall)
plt.xlabel('Clasa')
plt.ylabel('Recall')
plt.title('Recall pentru fiecare clasa')
plt.xticks(range(len(recall)), labels=range(len(recall)))
plt.show()

plt.figure(figsize=(48, 48))
plt.bar(range(len(support)), support)
plt.xlabel('Clasa')
plt.ylabel('Numar')
plt.title('Numarul de exemple din fiecare clasa')
plt.xticks(range(len(recall)), labels=range(len(recall)))
plt.show()
